window.addEventListener('DOMContentLoaded', () => {


	const btn = document.querySelector('.menu-btn'),
		navMenu = document.querySelector('.header-nav__menu'),
		navMenuActive = document.querySelector('.header-nav__active');



	btn.addEventListener('click', function () {
		navMenu.classList.toggle('header-nav__active');
		btn.classList.toggle('menu-btn-active');

	});

});
// var menuBtn = document.querySelector('.menu-btn');
// var menu = document.querySelector('.header-nav');
// menuBtn.addEventListener('click', function () {
// 	menu.classList.toggle('header-nav-active');
// 	menuBtn.classList.toggle('menu-btn-active');
// });



// $(document).ready(function () {
// 	$('.menu-btn').click(function () {
// 		$('.header-nav__menu').slideToggle(400);
// 		$('.header-nav__menu').css({
// 			"display": "flex"
// 		});
// 		$(".menu-btn").toggleClass('menu-btn-active');
// 	});
// });